#!/bin/bash

set -ex

SCRIPTPATH="$( cd "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P )"

cp -f $SCRIPTPATH/config.txt /boot
cp -f $SCRIPTPATH/zynthian_envars.sh /zynthian/config

cp -fr $SCRIPTPATH/cutiepi-display/* /boot/overlays

cd /boot/overlays
dtc -I dts -O dtb -o cutiepi-panel.dtbo cutiepi-panel-overlay.dts

